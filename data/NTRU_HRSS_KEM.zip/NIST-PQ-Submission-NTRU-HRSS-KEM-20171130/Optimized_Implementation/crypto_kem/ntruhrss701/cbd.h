#ifndef CBD_H
#define CBD_H

#include <stdint.h>
#include "poly.h"

void cbdS3(poly *r, const uint32_t *buf);

#endif
